package com.exceptionshandling;

import java.util.InputMismatchException;
import java.util.Scanner;

public class UsingTryCatchBlock {

    void main(){

        test();

    }


    static void test(){

        Scanner scanner = new Scanner(System.in);

        try {

            System.out.println("ENTER NUM1 : ");
            int num1 = scanner.nextInt();

            System.out.println("ENTER NUM2 : ");
            int num2 = scanner.nextInt();

            IO.println(num1 / num2);

            String s = null;
            IO.println(s.length());

//      }catch (InputMismatchException | ArithmeticException e) {
//            IO.println("TAKE NUMBER");
//            throw new RuntimeException(e);
        }catch (InputMismatchException e) {
            IO.println("TAKE NUMBER ONLY!");
            e.printStackTrace();
        }catch (ArithmeticException e) {
            IO.println("DO NOT DIVIDE BY ZERO1!");
            e.printStackTrace();
        }catch (Exception e) {
            IO.println("SOMETHING WENT WRONG!");
            e.printStackTrace();
        }
    }
}
