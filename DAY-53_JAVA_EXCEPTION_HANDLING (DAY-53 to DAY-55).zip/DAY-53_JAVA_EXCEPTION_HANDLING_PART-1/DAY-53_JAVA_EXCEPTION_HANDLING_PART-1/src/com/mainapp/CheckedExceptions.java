package com.mainapp;

import java.util.Scanner;

public class CheckedExceptions {

    void main(){

        IO.println("Hello World!");
        IO.println("Hello World!");
        IO.println("Hello World!");
        IO.println("Hello World!");
        IO.println("Hello World!");

        // PROGRAM: TERMINATE (Abnormal Termination)
        Scanner scanner = new Scanner(System.in);
        System.out.println("ENTER YOUR AGE : ");
        int age = scanner.nextInt();
        IO.println("YOUR AGE : " + age);
        //if you enter String in age : Exception in thread "main" java.util.InputMismatchException

        IO.println("Hello World!");
        IO.println("Hello World!");
        IO.println("Hello World!");
        IO.println("Hello World!");
        IO.println("Hello World!");

        String s = null;
        IO.println(s);
//        IO.println(s.length()); //Exception in thread "main" java.lang.NullPointerException

        int[] arr = {11,22,33,55,55};
//        IO.println(arr[6]); // Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException


        System.out.println("ENTER NUM1 : ");
        int num1 = scanner.nextInt();

        System.out.println("ENTER NUM2 : ");
        int num2 = scanner.nextInt();

        IO.println(num1 / num2); // Exception in thread "main" java.lang.ArithmeticException: / by zero
    }
}
