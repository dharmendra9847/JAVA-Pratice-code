package com.customexception;

import java.util.Scanner;

public class Launch {

    void main() {

        try {
            test();
        } catch (InvalidAgeException e) {
            throw new RuntimeException(e);
        }
    }

    void test() throws InvalidAgeException {

        Scanner scanner = new Scanner(System.in);
        IO.println("ENTER AGE  : ");
        int age = scanner.nextInt();
        if (age < 18) {
//            throw new ArithmeticException("AGE >= 18"); // UNCHECKED Exception
//            throw new InvalidAgeException(); // UNCHECKED Exception
            throw new InvalidAgeException("AGE >= 18"); // UNCHECKED Exception
        }
        IO.println("YOUR AGE : " + age);

    }
}
