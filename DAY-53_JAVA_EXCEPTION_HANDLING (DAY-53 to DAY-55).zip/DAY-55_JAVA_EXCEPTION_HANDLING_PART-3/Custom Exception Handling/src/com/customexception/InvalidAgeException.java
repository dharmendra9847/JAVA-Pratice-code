package com.customexception;

//public class InvalidAgeException extends RuntimeException {
//
//    public InvalidAgeException(String s) {
//        super(s);
//    }
//}

public class InvalidAgeException extends Exception {

    public InvalidAgeException(String s) {
        super(s);
    }
}
