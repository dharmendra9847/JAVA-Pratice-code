package com.throwkeyword;

import java.util.Scanner;

public class ThrowKeyword {

    void main(){
        try {
            test();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
    void test() throws ClassNotFoundException {

        Scanner scanner = new Scanner(System.in);
        IO.println("ENTER AGE  : ");
        int age = scanner.nextInt();
        if (age < 18){
//            throw new ArithmeticException("AGE >= 18"); // UNCHECKED Exception
            throw new ClassNotFoundException("AGE >= 18"); // CHECKED Exception
        }
        IO.println("YOUR AGE : " + age);

    }
}
