package com.checkedexception;

import java.util.Scanner;

public class DemoCheckedException {

    static int test() throws Exception{

        Scanner scanner = new Scanner(System.in);

        IO.println("ENTER NUM1");
        int num1 = scanner.nextInt();

        IO.println("ENTER NUM2");
        int num2 = scanner.nextInt();

        return num1 + num2;
    }
}
