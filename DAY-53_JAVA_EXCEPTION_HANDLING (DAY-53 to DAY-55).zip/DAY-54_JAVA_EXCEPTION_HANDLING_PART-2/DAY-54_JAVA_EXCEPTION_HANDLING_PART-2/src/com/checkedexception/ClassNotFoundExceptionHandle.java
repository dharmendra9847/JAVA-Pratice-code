package com.checkedexception;

public class ClassNotFoundExceptionHandle {

//    void main() throws ClassNotFoundException{
//
//        Class.forName("abc");
//    }
//    void main() throws ClassNotFoundException{
//
//        try {
//            Class.forName("abc");
//            IO.println("******");
//        } catch (ClassNotFoundException e) {
//            IO.println("ClassNotFoundException");
//            e.printStackTrace();
//        }
//    }

        void main() throws ClassNotFoundException{

        Class.forName("com.mainapp.Checked");
    }
}
