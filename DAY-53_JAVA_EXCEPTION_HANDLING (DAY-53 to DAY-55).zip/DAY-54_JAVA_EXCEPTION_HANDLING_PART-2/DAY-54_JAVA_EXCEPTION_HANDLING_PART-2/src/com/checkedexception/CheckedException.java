package com.checkedexception;

public class CheckedException {

    void main(){

        int demo = 0;
        try {
            demo = DemoCheckedException.test(); // CALLER
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        IO.println(demo);

        IO.println("EXIT");

    }

}
