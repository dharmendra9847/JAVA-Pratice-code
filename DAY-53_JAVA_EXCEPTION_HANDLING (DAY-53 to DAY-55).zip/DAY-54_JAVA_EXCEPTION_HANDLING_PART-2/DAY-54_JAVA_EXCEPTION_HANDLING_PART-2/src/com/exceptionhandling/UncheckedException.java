package com.exceptionhandling;

import java.util.Scanner;

public class UncheckedException {

    void main(){

        test();
    }

    int test() throws RuntimeException{

        Scanner scanner = new Scanner(System.in);

        IO.println("ENTER NUM1");
        int num1 = scanner.nextInt();

        IO.println("ENTER NUM2");
        int num2 = scanner.nextInt();

        return num1 + num2;
    }
}
