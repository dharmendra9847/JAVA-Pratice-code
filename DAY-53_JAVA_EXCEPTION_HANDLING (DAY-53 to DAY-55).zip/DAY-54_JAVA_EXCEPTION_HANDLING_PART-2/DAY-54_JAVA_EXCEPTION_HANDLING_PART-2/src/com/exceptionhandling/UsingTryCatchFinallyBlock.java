package com.exceptionhandling;

import java.util.Scanner;

public class UsingTryCatchFinallyBlock {

    void main(){

        test();

    }

    int test(){

        Scanner scanner = new Scanner(System.in);

        try {
            IO.println("ENTER NUM1");
            int num1 = scanner.nextInt();

            IO.println("ENTER NUM2");
            int num2 = scanner.nextInt();

            return num1 + num2;
        } catch (Exception e) {
            IO.println("SOMETHING WENT WRONG!");
            e.printStackTrace();
        } finally {
            IO.println("CLOSING...");
        }
        return 0;
    }
}
