void main(){
    IO.println("\nWelcome to String Input!");

    Scanner scanner = new Scanner(System.in);

    // FOR INTEGER
    IO.println("ENTER YOUR ROLL : ");
    int roll = scanner.nextInt(); //1234 \n
    IO.println(roll);

    // INPUT BUFFER: \n

    // FOR WORD ( next() )
    IO.println("ENTER YOUR CITY : ");
    String city = scanner.next();
    IO.println(city);

    // INPUT BUFFER: \n
    scanner.nextLine();

    // SENTENCE ( nextLine() )
    IO.println("ENTER YOUR FULL NAME : ");
    String fullName = scanner.nextLine();
    IO.println(fullName);
}
