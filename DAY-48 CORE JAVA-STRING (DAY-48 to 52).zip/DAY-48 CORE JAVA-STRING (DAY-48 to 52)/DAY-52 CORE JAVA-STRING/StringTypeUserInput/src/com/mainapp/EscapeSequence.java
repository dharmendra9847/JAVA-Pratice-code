package com.mainapp;

public class EscapeSequence {

    static void main(){

        IO.println("Hello World");
        IO.println("HelloWorld");
        IO.println("Hello\nWorld"); //nextLine

        IO.println("Hello\tWorld"); // tab
        IO.println("Hello \"World\"");
        IO.println("Hello World : + " + "$");
        IO.println("Hello World : 'XYZ' " + '\'');
        IO.println("c:\\Usres\\Dell\\Decstop\\Project");
        IO.println("UNICODE: \u265A");

        IO.println("Hello" + "\\n" + "World");

    }
}
