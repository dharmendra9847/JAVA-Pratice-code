package com.mainapp;

public class ConstNonConstPool {

    static  void main(){

        String s = "Raju";
        IO.println(s);
        String k = "Ra".concat("ju");
        IO.println(k);

        if (s == k){
            IO.println("Ture");
        }else {
            IO.println("False");
        }
    }
}
