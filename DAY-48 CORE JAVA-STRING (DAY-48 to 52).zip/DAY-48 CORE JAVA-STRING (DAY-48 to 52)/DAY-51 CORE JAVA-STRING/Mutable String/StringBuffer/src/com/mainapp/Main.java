void main() {

    StringBuffer s = new StringBuffer("Raja");
    IO.println(s);

    s.append(" Kumar");
    IO.println("Append : " + s);

    s.insert(2, "***");
    IO.println("Insert : " + s);

    s.delete(4,6);
    IO.println("Delete : " + s);

    s.reverse();
    IO.println("Reverse : " + s);
    IO.println(s + " " + s.length());

}
