package com.mainapp;

public class Lunch {

	public static void main(String[] args) {

		String k = "Dharmendra";	// CONSTANT POOL
		
		String s = new String("Dharmendra"); // NON CONSTANT POOL
		 
		// intern() return String
		String p = s.intern(); // CONSTANT POOL
		System.out.println(p);
		
		// replace(0,0) return String
		String k2 = k.replace("Dharmendra", "Neha");
		System.out.println("Replace : " + k2);
		
		// trim() return String
		String abc = "    My Name is Ali";
		String trimString = abc.trim();
		System.out.println("Trim : " + trimString);
		
		// compareTo return int
		String a1 = "abcdefgh";
		String a2 = "abcdefgh";
		int compareTo = a1.compareTo(a2);
		System.out.println("compareTo : " + compareTo); // 0
		
		String b1 = "abcdefgh";
		String b2 = "abcgefgh";
		int c = b1.compareTo(b2);
		System.out.println("compareTo : " + c); // -3
		
		String c1 = "abcgefgh";
		String c2 = "abcdefgh";
		int d = c1.compareTo(c2);
		System.out.println("compareTo : " + d); // 3
		
	}

}
