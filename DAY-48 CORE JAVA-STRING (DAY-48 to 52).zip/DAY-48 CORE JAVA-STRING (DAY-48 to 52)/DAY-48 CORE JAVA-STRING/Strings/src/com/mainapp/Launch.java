package com.mainapp;

public class Launch {

    static void main() {

//        StringTypes.StringTypes();
//        StringImmutable.stringImmutable();
//        StringManipulation.stringManipulation();
        StringMethods.stringMethods();
    }
}
