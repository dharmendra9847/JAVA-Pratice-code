package com.mainapp;

public class StringImmutable {

    static void stringImmutable(){

        String s = "Raju";
        s.concat(" Hi,"); //Result of 'String.concat()' is ignored

        System.out.println("S: " + s);

        String r = s.concat(" Hi,");
        String p = s.concat(" Raju");
        String q = s.concat(", Weclome to my house!");

        System.out.println(r);
        System.out.println(p);
        System.out.println(q);

        System.out.println(r + p + q);


    }
}
