package com.mainapp;

public class StringMethods {

    public static void stringMethods(){

    }
}
