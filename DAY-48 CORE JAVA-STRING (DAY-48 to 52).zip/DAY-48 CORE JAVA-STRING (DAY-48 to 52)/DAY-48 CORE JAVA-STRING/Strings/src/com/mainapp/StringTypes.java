package com.mainapp;

public class StringTypes {

    static void stringTypes() {

        // WITHOUT NEW KEYWORD
        String str = "Raju";
        System.out.println(str);

        // WITH NEW KEYWORD (RARELY USE)
        String s = new String("String");
        System.out.println(s);


        String k = "raju";
        String l = "raju";

        if (k == l){
            System.out.println("REFERENCE OF " + k + " & " + l + " ARE EQUAL!");
        }else {
            System.out.println("REFERENCE ARE NOT EQUAL!");
        }


        String p = new String("India");
        String q = new String("India");
        if (p == q){
            System.out.println("REFERENCE OF " + p + " & " + q + " ARE EQUAL!");
        }else {
            System.out.println("REFERENCE OF " + p + " & " + q + " ARE NOT EQUAL!");
        }

    }
}
