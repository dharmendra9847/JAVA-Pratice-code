package com.mainapp;

public class StringManipulation {

    static void stringManipulation(){


        String special = "sj@ hsh122& *$";
        String result = "";
        for (int i = 0; i < special.length(); i++) {
            char ch = special.charAt(i);
            if (Character.isLetter(ch)){
                result += ch;
            }
        }
        System.out.println(result);

    }
}
