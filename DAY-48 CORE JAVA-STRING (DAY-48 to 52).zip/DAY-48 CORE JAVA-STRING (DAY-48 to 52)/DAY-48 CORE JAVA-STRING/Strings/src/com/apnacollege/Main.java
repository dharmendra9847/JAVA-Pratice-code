package com.apnacollege;

import java.util.Scanner;

import static java.lang.Integer.parseInt;

public class Main {

    static void main() {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Your Name : ");
        String name = sc.next();

        sc.nextLine();             // consume leftover newline

        System.out.println("Your Name is : " + name);

        System.out.println("Enter Your Full Name : ");
        String fullName = sc.nextLine();
        System.out.println("Your Full Name is : " + fullName);

        System.out.println("Enter Your College Name : ");
        String collegeName = sc.nextLine();
        System.out.println("Your Full Name is : " + fullName);

        // CONCATENATION
        String firstName = "Tony";
        String lastName = "Stark";
        System.out.println("Full Name : " + firstName + " " + lastName);

        // LENGTH()
        System.out.println("String Length : " + fullName.length());

        // charAt()
        for (int i = 0; i < fullName.length(); i++) {
            System.out.print(fullName.charAt(i) + " ");
        }

        System.out.println();

        // String Compare using compareTo() Method
        String name1 = "Tony";
        String name2 = "Tony2";

        if (name1.compareTo(name2) == 0){
            System.out.println("String are equal!");
        } else {
            System.out.println("String are not equal!");
        }

        if (new String("Tony") == new String("Tony")){
            System.out.println("String are equal!");
        } else {
            System.out.println("String are not equal!");
        }


        if (name1.length() == name2.length()){
            System.out.println("Strings Are Equal!");
        } else if (name1.length() > name2.length()) {
            System.out.println("nume1 is greater than name2!");
        } else if (name1.length() < name2.length()) {
            System.out.println("nume1 is less than name2!");
        } else if (name1.length() >= name2.length()) {
            System.out.println("nume1 is greater than or equal to name2!");
        } else if (name1.length() <= name2.length()) {
            System.out.println("nume1 is less than or equal to name2!");
        }   else {
            System.out.println("Strings Are Not Equal!");
        }


        if (name1.contains(name2)){
            System.out.println("Strings Are Equal!");
        }else {
            System.out.println("Strings Are Not Equal!");
        }
        if (name2.equals(name1)){
            System.out.println("Strings Are Equal!");
        }else {
            System.out.println("Strings Are Not Equal!");
        }

        // SUBSTRING
        String sentence = "My name id Tony";
        String sentencePrint = sentence.substring(0,6);
        System.out.println(sentencePrint);
        System.out.println(sentence.substring(11));

        // TypeCast using String.valueOf(number)
        int a =  12;
        String b = String.valueOf(a);
        System.out.println(b);

        // TypeCast using Integer.toString(number)
        int num1 = 4559;
        String num2 = Integer.toString(num1);
        System.out.println(num2);

        // Strings Are Immutable

        sc.close();
    }
}
